namespace Gamification.Domain.Model;

public record Badge(string Slug, string Title);